package br.com.steelix.gestao_empresa.service;

import br.com.steelix.gestao_empresa.dto.EmpregadoDto;
import br.com.steelix.gestao_empresa.model.Empregado;
import br.com.steelix.gestao_empresa.model.Empresa;
import br.com.steelix.gestao_empresa.repository.EmpregadoRepository;
import br.com.steelix.gestao_empresa.repository.EmpresaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class EmpregadoService {
    private final EmpregadoRepository empregadoRepository;

    @Autowired
    public EmpregadoService(EmpregadoRepository empregadoRepository) {
        this.empregadoRepository = empregadoRepository;
    }

    public List<EmpregadoDto> listar(){
        return empregadoRepository.findAll().stream().map(Empregado::toDto).collect(Collectors.toList());
    }

    public EmpregadoDto salvar(EmpregadoDto dto) {
        return empregadoRepository.save(dto.toEntity()).toDto();
    }

    public void remover(Long id) {
        empregadoRepository.deleteById(id);
    }


}
