import './ModalCadastroEmpresa.css';
import {Button, FormControl, FormLabel, InputGroup, Modal} from "react-bootstrap";

const ModalCadastroEmpresa = (props) => {
    return (
        <Modal {...props} size="lg" arial-labelledby="modal-title-cadastro-empresa" centered>
            <Modal.Header closeButton>
                <Modal.Title id="modal-title-cadastro-empresa">
                    Cadastro Empresa
                </Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <InputGroup className="mb-3">
                    <FormLabel htmlFor="nome">Nome</FormLabel>
                    <FormControl id="nome" arial-label="Nome" aria-describedby="nome"></FormControl>
                </InputGroup>

                <InputGroup className="mb-3">
                    <FormLabel htmlFor="descricao">Descrição</FormLabel>
                    <FormControl id="descricao" arial-label="descricao" aria-describedby="descricao"></FormControl>
                </InputGroup>

                <div className="form-group">
                    <Button variant="primary">
                        Salvar
                    </Button>
                </div>
            </Modal.Body>
            <Modal.Footer>
                <Button onClick={props.onHide}>Close</Button>
            </Modal.Footer>
        </Modal>
    );
}

export default ModalCadastroEmpresa;
