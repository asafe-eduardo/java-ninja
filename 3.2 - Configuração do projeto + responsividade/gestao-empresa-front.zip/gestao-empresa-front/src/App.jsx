import "./styles.css";
import 'bootstrap/dist/css/bootstrap.min.css';
import GestaoEmpresaNavbar from "./components/GestaoEmpresaNavbar/GestaoEmpresaNavbar";
import GestaoEmpresaHome from "./components/GestaoEmpresaHome/GestaoEmpresaHome";
import {Container} from "react-bootstrap";
export default function App() {
  return (
    <div className="App">
      <h1>Hello CodeSandbox</h1>
      <h2>Start editing to see some magic happen!</h2>
    </div>
  );
}
