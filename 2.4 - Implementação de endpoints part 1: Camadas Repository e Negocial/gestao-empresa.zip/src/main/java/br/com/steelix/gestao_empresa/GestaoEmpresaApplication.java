package br.com.steelix.gestao_empresa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestaoEmpresaApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestaoEmpresaApplication.class, args);
	}

}
