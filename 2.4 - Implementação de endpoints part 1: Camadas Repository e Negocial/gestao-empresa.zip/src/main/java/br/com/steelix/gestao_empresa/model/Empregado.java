package br.com.steelix.gestao_empresa.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Entity
@Table(name = "TB_EMPREGADO")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Empregado {

    @Id
    @Column(name = "ID_EMPREGADO")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "NOME_EMPREGADO", nullable = false)
    private String nome;

    @Column(name = "FUNCAO", nullable = false)
    private String funcao;

    @ManyToOne
    @JoinColumn(name = "ID_EMPRESA", referencedColumnName = "ID_EMPRESA")
    private Empresa empresa;

    @OneToMany(mappedBy = "empregado", fetch = FetchType.LAZY)
    private List<Competencia> competencias;
}
