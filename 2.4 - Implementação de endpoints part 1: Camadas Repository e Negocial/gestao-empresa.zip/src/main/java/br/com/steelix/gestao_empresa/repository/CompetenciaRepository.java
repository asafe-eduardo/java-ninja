package br.com.steelix.gestao_empresa.repository;

import br.com.steelix.gestao_empresa.model.Competencia;
import br.com.steelix.gestao_empresa.model.Empregado;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CompetenciaRepository extends JpaRepository<Competencia, Long> {
}
