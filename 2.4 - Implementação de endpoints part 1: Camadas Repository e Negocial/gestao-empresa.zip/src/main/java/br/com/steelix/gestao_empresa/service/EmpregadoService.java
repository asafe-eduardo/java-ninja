package br.com.steelix.gestao_empresa.service;

import br.com.steelix.gestao_empresa.model.Empregado;
import br.com.steelix.gestao_empresa.model.Empresa;
import br.com.steelix.gestao_empresa.repository.EmpregadoRepository;
import br.com.steelix.gestao_empresa.repository.EmpresaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmpregadoService {
    private final EmpregadoRepository empregadoRepository;

    @Autowired
    public EmpregadoService(EmpregadoRepository empregadoRepository) {
        this.empregadoRepository = empregadoRepository;
    }

    public List<Empregado> listar(){
        return empregadoRepository.findAll();
    }

    public Empregado salvar(Empregado empregado) {
        return empregadoRepository.save(empregado);
    }

    public void remover(Long id) {
        empregadoRepository.deleteById(id);
    }


}
