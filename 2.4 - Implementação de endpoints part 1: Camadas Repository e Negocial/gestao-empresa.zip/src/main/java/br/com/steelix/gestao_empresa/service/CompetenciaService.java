package br.com.steelix.gestao_empresa.service;

import br.com.steelix.gestao_empresa.model.Competencia;
import br.com.steelix.gestao_empresa.model.Empregado;
import br.com.steelix.gestao_empresa.repository.CompetenciaRepository;
import br.com.steelix.gestao_empresa.repository.EmpregadoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CompetenciaService {
    private final CompetenciaRepository competenciaRepository;

    @Autowired
    public CompetenciaService(CompetenciaRepository competenciaRepository) {
        this.competenciaRepository = competenciaRepository;
    }

    public List<Competencia> listar(){
        return competenciaRepository.findAll();
    }

    public Competencia salvar(Competencia competencia) {
        return competenciaRepository.save(competencia);
    }

    public void remover(Long id) {
        competenciaRepository.deleteById(id);
    }


}
