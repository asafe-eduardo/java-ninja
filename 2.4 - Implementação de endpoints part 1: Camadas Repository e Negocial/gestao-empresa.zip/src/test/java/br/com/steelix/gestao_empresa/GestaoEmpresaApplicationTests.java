package br.com.steelix.gestao_empresa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestaoEmpresaApplicationTests {

	@Test
	void contextLoads() {
	}

}
