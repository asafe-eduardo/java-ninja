import './GestaoEmpresaNavbar.css';
import {Anchor, Navbar} from "react-bootstrap";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faS} from "@fortawesome/free-solid-svg-icons";

export default function GestaoEmpresaNavbar(){
    return (
        <Navbar id="navbar" className="navbar bg-body-tertiary" style={{padding: '10px'}}>
            <FontAwesomeIcon icon={faS}></FontAwesomeIcon>
            <Anchor className="navbar-brand gestao-empresa-navbar" href="#">Steelix</Anchor>
        </Navbar>
    );
}
