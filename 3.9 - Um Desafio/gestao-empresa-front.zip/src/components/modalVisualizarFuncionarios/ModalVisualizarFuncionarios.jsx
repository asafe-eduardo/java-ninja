import './ModalVisualizarFuncionarios.css';
import {Button, ButtonGroup, Modal, Table} from "react-bootstrap";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faEye, faTrash} from "@fortawesome/free-solid-svg-icons";

const ModalVisualizarFuncionarios = (props) => {
    return (
        <Modal {...props} size="lg" arial-labelledby="modal-title-visualizar-funcionarios" centered>
            <Modal.Header closeButton>
                <Modal.Title id="modal-title-visualizar-funcionarios">
                    Visualizar Funcionarios
                </Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <Table striped bordered hover>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nome</th>
                            <th>Função</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>João Costa</td>
                            <td>Desenvolvedor</td>
                            <td>
                                <ButtonGroup>
                                    <Button type="button" variant="danger">
                                        <FontAwesomeIcon icon={faTrash}></FontAwesomeIcon>
                                        Excluir
                                    </Button>
                                </ButtonGroup>
                            </td>
                        </tr>
                    </tbody>
                </Table>
            </Modal.Body>
            <Modal.Footer>
                <Button onClick={props.onHide}>Close</Button>
            </Modal.Footer>
        </Modal>
    );
}

export default ModalVisualizarFuncionarios;
