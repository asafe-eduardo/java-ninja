import './ModalCadastroEmpresa.css';
import {Button, FormControl, FormLabel, InputGroup, Modal} from "react-bootstrap";
import {salvarEmpresa} from "../../services/GestaoEmpresaApi";
import {useState} from "react";

const ModalCadastroEmpresa = (props) => {

    const [nome, setNome] = useState('');
    const [descricao, setDescricao] = useState('');

    function onChangeNome(event){
        setNome(event.target.value);
    }

    function onChangeDescricao(event){
        setDescricao(event.target.value);
    }
    function salvar(event){
        event.preventDefault();

        salvarEmpresa({id: 0, nome: nome, descricao: descricao}).then(resp => {
            props.onHide();
        })
    }


    return (
        <Modal {...props} size="lg" arial-labelledby="modal-title-cadastro-empresa" centered>
            <Modal.Header closeButton>
                <Modal.Title id="modal-title-cadastro-empresa">
                    Cadastro Empresa
                </Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <InputGroup className="mb-3">
                    <FormLabel style={{marginRight: '1%'}}  htmlFor="nome">Nome</FormLabel>
                    <FormControl id="nome" arial-label="Nome" aria-describedby="nome" value={nome} onChange={onChangeNome}></FormControl>
                </InputGroup>

                <InputGroup className="mb-3">
                    <FormLabel style={{marginRight: '1%'}} htmlFor="descricao">Descrição</FormLabel>
                    <FormControl id="descricao" arial-label="descricao" aria-describedby="descricao" value={descricao} onChange={onChangeDescricao}></FormControl>
                </InputGroup>

                <div className="form-group">
                    <Button variant="primary" onClick={salvar}>
                        Salvar
                    </Button>
                </div>
            </Modal.Body>
            <Modal.Footer>
                <Button onClick={props.onHide}>Close</Button>
            </Modal.Footer>
        </Modal>
    );
}

export default ModalCadastroEmpresa;
