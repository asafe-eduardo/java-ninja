import './GestaoEmpresaFooter.css';

const GestaoEmpresaFooter = ()=>{
    return (
        <footer className="gestao-empresa-footer footer">
            <span>Versão: 1.0.0</span>
        </footer>
    );
}

export default GestaoEmpresaFooter;
