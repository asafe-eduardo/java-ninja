import './GestaoEmpresaHome.css';
import {Button} from "react-bootstrap";
import GestaoEmpresaTabela from "../tabela/GestaoEmpresaTabela";
import ModalCadastroEmpresa from "../modalCadastroEmpresa/ModalCadastroEmpresa";
import {useEffect, useState} from "react";
import {buscarEmpresas} from "../../services/GestaoEmpresaApi";

const GestaoEmpresaHome = () => {
    const [modalShow, setModalShow] = useState(false);
    const [empresas, setEmpresas] = useState([]);

    useEffect(() => {
        buscarEmpresas().then((resp) => {
            setEmpresas(resp);
        })
    }, []);


    return (
        <div>
            <ModalCadastroEmpresa show={modalShow} onHide={() => setModalShow(false)}></ModalCadastroEmpresa>
            <GestaoEmpresaTabela data={empresas}></GestaoEmpresaTabela>
            <div className="form-group">
                <Button variant="primary"
                        style={{float: "right"}}
                        onClick={() => setModalShow(true)}>
                    Cadastrar Empresa
                </Button>
            </div>
        </div>
    );
}

export default GestaoEmpresaHome;
