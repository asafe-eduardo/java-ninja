import axios from "axios";

const urlBase = "http://localhost:8080";
export async function buscarEmpresas(){
    const empresasResponse = await axios.get(`${urlBase}/empresa`);
    return empresasResponse.data;
}

export async function salvarEmpresa(empresa) {
    await axios.post(`${urlBase}/empresa`, empresa)
}
