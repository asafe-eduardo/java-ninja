import "./styles.css";
import 'bootstrap/dist/css/bootstrap.min.css';
import GestaoEmpresaNavbar from "./components/GestaoEmpresaNavbar/GestaoEmpresaNavbar";
import GestaoEmpresaHome from "./components/GestaoEmpresaHome/GestaoEmpresaHome";
import {Container} from "react-bootstrap";
export default function App() {
  return (
    <div className="App">
      <GestaoEmpresaNavbar></GestaoEmpresaNavbar>
        <Container className="p-12">
            <GestaoEmpresaHome></GestaoEmpresaHome>
        </Container>
    </div>
  );
}
