import './GestaoEmpresaHome.css';
import {Button} from "react-bootstrap";
import GestaoEmpresaTabela from "../tabela/GestaoEmpresaTabela";
import ModalCadastroEmpresa from "../modalCadastroEmpresa/ModalCadastroEmpresa";
import {useState} from "react";

const GestaoEmpresaHome = () => {
    const [modalShow, setModalShow] = useState(false);

    return (
        <div>
            <ModalCadastroEmpresa show={modalShow} onHide={() => setModalShow(false)}></ModalCadastroEmpresa>
            <GestaoEmpresaTabela></GestaoEmpresaTabela>
            <div className="form-group">
                <Button variant="primary"
                        style={{float: "right"}}
                        onClick={() => setModalShow(true)}>
                    Cadastrar Empresa
                </Button>
            </div>
        </div>
    );
}

export default GestaoEmpresaHome;
