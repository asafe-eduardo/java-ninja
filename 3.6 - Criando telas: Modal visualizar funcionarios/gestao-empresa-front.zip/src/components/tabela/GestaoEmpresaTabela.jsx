import './GestaoEmpresaTabela.css';
import {Button, ButtonGroup, Table} from "react-bootstrap";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faEye, faTrash} from "@fortawesome/free-solid-svg-icons";
import {useState} from "react";
import ModalVisualizarFuncionarios from "../modalVisualizarFuncionarios/ModalVisualizarFuncionarios";

const GestaoEmpresaTabela = () => {
    const [modalShow, setModalShow] = useState(false);

    return (
        <div style={{marginTop: '%2'}}>
            <ModalVisualizarFuncionarios show={modalShow} onHide={() => setModalShow(false)}></ModalVisualizarFuncionarios>
            <Table striped bordered hover>
                <thead>
                <tr>
                    <th>#</th>
                    <th>Nome</th>
                    <th>Descrição</th>
                    <th>Ações</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>1</td>
                    <td>Teste edu</td>
                    <td>Teste edu</td>
                    <td>
                        <ButtonGroup>
                            <Button type="button" variant="danger">
                                <FontAwesomeIcon icon={faTrash}></FontAwesomeIcon>
                                Excluir
                            </Button>
                        </ButtonGroup>
                        <ButtonGroup style={{marginLeft: '1%'}}>
                            <Button type="button" variant="secondary"  onClick={() => setModalShow(true)}>
                                <FontAwesomeIcon icon={faEye}></FontAwesomeIcon>
                                Visualizar
                            </Button>
                        </ButtonGroup>
                    </td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Mais um teste</td>
                    <td>Mais um teste</td>
                    <td>
                        <ButtonGroup>
                            <Button type="button" variant="danger">
                                <FontAwesomeIcon icon={faTrash}></FontAwesomeIcon>
                                Excluir
                            </Button>
                        </ButtonGroup>
                        <ButtonGroup style={{marginLeft: '1%'}}>
                            <Button type="button" variant="secondary" onClick={() => setModalShow(true)}>
                                <FontAwesomeIcon icon={faEye}></FontAwesomeIcon>
                                Visualizar
                            </Button>
                        </ButtonGroup>
                    </td>
                </tr>
                </tbody>
            </Table>
        </div>
    );
}

export default GestaoEmpresaTabela;
