package br.com.steelix.gestao_empresa.dto;

import br.com.steelix.gestao_empresa.model.Empresa;
import lombok.Data;

@Data
public class EmpresaDto {
    private final Long id;
    private final String nome;
    private final String descricao;

    public Empresa toEntity(){
        Empresa empresa = new Empresa();
        empresa.setNome(this.nome);
        empresa.setDescricao(this.descricao);

        return empresa;
    }
}
