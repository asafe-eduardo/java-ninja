package br.com.steelix.gestao_empresa.controller;

import br.com.steelix.gestao_empresa.dto.EmpregadoDto;
import br.com.steelix.gestao_empresa.model.Empregado;
import br.com.steelix.gestao_empresa.model.Empresa;
import br.com.steelix.gestao_empresa.service.EmpregadoService;
import br.com.steelix.gestao_empresa.service.EmpresaService;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(value = "/empregado")
public class EmpregadoController {

    private final EmpregadoService empregadoService;

    public EmpregadoController(EmpregadoService empregadoService) {
        this.empregadoService = empregadoService;
    }

    @GetMapping
    public List<EmpregadoDto> listar(){
        return empregadoService.listar();
    }

    @GetMapping("/{nome}")
    public List<EmpregadoDto> buscarEmpregadoPorNome(@PathVariable(value = "nome") String nome){
        return empregadoService.buscarEmpregadoPorNome(nome);
    }

    @PostMapping
    public EmpregadoDto salvar(@RequestBody EmpregadoDto empregado) {
        return empregadoService.salvar(empregado);
    }

    @DeleteMapping("/{id}")
    public void remover(@PathVariable(value = "id") Long id){
        empregadoService.remover(id);
    }

}
