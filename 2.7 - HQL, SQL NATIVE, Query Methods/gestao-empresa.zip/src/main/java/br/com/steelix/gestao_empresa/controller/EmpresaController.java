package br.com.steelix.gestao_empresa.controller;

import br.com.steelix.gestao_empresa.dto.EmpresaDto;
import br.com.steelix.gestao_empresa.model.Empresa;
import br.com.steelix.gestao_empresa.service.EmpresaService;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping(value = "/empresa")
public class EmpresaController {

    private final EmpresaService empresaService;

    public EmpresaController(EmpresaService empresaService) {
        this.empresaService = empresaService;
    }

    @GetMapping
    public List<EmpresaDto> listar(){
        return empresaService.listar();
    }

    @GetMapping("/{nome}")
    public EmpresaDto buscarEmpresaPorNome(@PathVariable(value = "nome") String nome){
        return empresaService.buscarEmpresaPorNome(nome);
    }

    @GetMapping("/filtro")
    public List<Object[]> buscarEmpresaPorDescricao(@RequestParam(value = "descricao") String descricao){
        return empresaService.buscarEmpresaPorDescricao(descricao);
    }

    @PostMapping
    public EmpresaDto salvar(@RequestBody EmpresaDto dto) {
        return empresaService.salvar(dto);
    }

    @PutMapping
    public EmpresaDto atualizar(@RequestBody EmpresaDto dto) {
        if(dto.getId() == null) {
            throw new RuntimeException("É necessário informar um id");
        }
        return empresaService.salvar(dto);
    }

    @DeleteMapping("/{id}")
    public void remover(@PathVariable(value = "id") Long id){
        empresaService.remover(id);
    }

}
