package br.com.steelix.gestao_empresa.service;

import br.com.steelix.gestao_empresa.dto.EmpresaDto;
import br.com.steelix.gestao_empresa.model.Empresa;
import br.com.steelix.gestao_empresa.repository.EmpresaRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class EmpresaService {
    private final EmpresaRepository empresaRepository;

    @Autowired
    public EmpresaService(EmpresaRepository empresaRepository) {
        this.empresaRepository = empresaRepository;
    }

    public List<EmpresaDto> listar(){
        return empresaRepository.findAll().stream().map(Empresa::toDto).collect(Collectors.toList());
    }

    public EmpresaDto buscarEmpresaPorNome(String nome){
        return empresaRepository.buscarEmpresaPorNome(nome).toDto();
    }

    public List<Object[]> buscarEmpresaPorDescricao(String descricao){
        return empresaRepository.buscarEmpresaPorDescricao(descricao);
    }

    public EmpresaDto salvar(EmpresaDto dto) {
        return empresaRepository.save(dto.toEntity()).toDto();
    }

    public void remover(Long id) {
        empresaRepository.deleteById(id);
    }


}
