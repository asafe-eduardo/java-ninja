package br.com.steelix.gestao_empresa.dto;

import br.com.steelix.gestao_empresa.model.Empregado;
import br.com.steelix.gestao_empresa.model.Empresa;
import lombok.Data;

@Data
public class EmpregadoDto {
    private final Long id;
    private final String nome;
    private final String funcao;

    public Empregado toEntity(){
        Empregado empregado = new Empregado();
        empregado.setNome(this.getNome());
        empregado.setFuncao(this.funcao);

        return empregado;
    }
}
