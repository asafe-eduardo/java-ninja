package br.com.steelix.gestao_empresa.model;

import br.com.steelix.gestao_empresa.dto.EmpresaDto;
import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Entity
@Table(name = "TB_EMPRESA")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Empresa {

    @Id
    @Column(name = "ID_EMPRESA")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "NOME_EMPRESA", nullable = false)
    private String nome;

    @Column(name = "DESCRICAO_EMPRESA", nullable = false)
    private String descricao;

    @JsonBackReference
    @OneToMany(mappedBy = "empresa", fetch = FetchType.LAZY)
    private List<Empregado> empregados;

    public EmpresaDto toDto(){
        return new EmpresaDto(this.id, this.nome, this.descricao);
    }

}
