package br.com.steelix.gestao_empresa.controller;

import br.com.steelix.gestao_empresa.model.Competencia;
import br.com.steelix.gestao_empresa.model.Empregado;
import br.com.steelix.gestao_empresa.service.CompetenciaService;
import br.com.steelix.gestao_empresa.service.EmpregadoService;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(value = "/competencia")
public class CompetenciaController {

    private final CompetenciaService competenciaService;

    public CompetenciaController(CompetenciaService competenciaService) {
        this.competenciaService = competenciaService;
    }

    @GetMapping
    public List<Competencia> listar(){
        return competenciaService.listar();
    }

    @PostMapping
    public Competencia salvar(@RequestBody Competencia competencia) {
        return competenciaService.salvar(competencia);
    }

    @DeleteMapping("/{id}")
    public void remover(@PathVariable(value = "id") Long id){
        competenciaService.remover(id);
    }

}
