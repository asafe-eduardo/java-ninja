package br.com.steelix.gestao_empresa.repository;

import br.com.steelix.gestao_empresa.model.Empresa;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmpresaRepository extends JpaRepository<Empresa, Long> {

    @Query("SELECT e FROM Empresa e WHERE e.nome = :nome")
    Empresa buscarEmpresaPorNome(@Param("nome") String nome);

    @Query(value = "SELECT * FROM TB_EMPRESA e WHERE DESCRICAO_EMPRESA LIKE %:descricao%" , nativeQuery = true)
    List<Object[]> buscarEmpresaPorDescricao(@Param("descricao") String descricao);

}
