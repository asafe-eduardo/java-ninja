import './GestaoEmpresaHome.css';
import {Button} from "react-bootstrap";
import GestaoEmpresaTabela from "../tabela/GestaoEmpresaTabela";

const GestaoEmpresaHome = () => {
    return (
        <div>
            <GestaoEmpresaTabela></GestaoEmpresaTabela>
            <div className="form-group">
                <Button variant="primary"
                        style={{float: "right"}}
                        onClick={() => console.log('Clicou!')}>
                    Cadastrar Empresa
                </Button>
            </div>
        </div>
    );
}

export default GestaoEmpresaHome;
