import axios from "axios";

export async function buscarEmpresas(){
    const empresasResponse = await axios.get('http://localhost:8080/empresa');
    return empresasResponse.data;
}
